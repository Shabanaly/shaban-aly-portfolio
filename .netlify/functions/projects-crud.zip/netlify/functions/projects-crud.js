var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var projects_crud_exports = {};
__export(projects_crud_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(projects_crud_exports);
var import_pg = require("pg");
const pool = new import_pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    };
  }
  const method = event.queryStringParameters?.method || event.httpMethod;
  try {
    if (method === "GET") {
      return await handleGet();
    } else if (method === "POST") {
      return await handlePost(event);
    } else if (method === "DELETE") {
      return await handleDelete(event);
    } else {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "Method Not Allowed" })
      };
    }
  } catch (error) {
    console.error("CRUD error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
}
async function handleGet() {
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT id, title, description, image, link, created_at FROM projects ORDER BY created_at DESC"
    );
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        projects: result.rows
      })
    };
  } finally {
    client.release();
  }
}
async function handlePost(event) {
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ success: false, error: "Invalid JSON" })
    };
  }
  const { title, description, image, link } = body;
  if (!title || !description || !image) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: false,
        error: "Missing required fields: title, description, image"
      })
    };
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      "INSERT INTO projects (title, description, image, link, created_at) VALUES ($1, $2, $3, $4, NOW()) RETURNING id",
      [title, description, image, link || null]
    );
    return {
      statusCode: 201,
      headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        projectId: result.rows[0].id
      })
    };
  } finally {
    client.release();
  }
}
async function handleDelete(event) {
  const id = event.queryStringParameters?.id;
  if (!id) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ success: false, error: "Missing project id" })
    };
  }
  const client = await pool.connect();
  try {
    const result = await client.query("DELETE FROM projects WHERE id = $1", [id]);
    if (result.rowCount === 0) {
      return {
        statusCode: 404,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ success: false, error: "Project not found" })
      };
    }
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        message: "Project deleted"
      })
    };
  } finally {
    client.release();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
