var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var upload_image_exports = {};
__export(upload_image_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(upload_image_exports);
var import_cloudinary = require("cloudinary");
var import_pg = require("pg");
var import_stream = require("stream");
import_cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});
const pool = new import_pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    };
  }
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        body: JSON.stringify({ error: "Method Not Allowed" })
      };
    }
    const { file, filename } = await parseMultipart(event);
    if (!file) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "No file uploaded" })
      };
    }
    const uploadResult = await uploadToCloudinary(file, filename);
    if (!uploadResult.secure_url) {
      throw new Error("Upload failed");
    }
    const client = await pool.connect();
    try {
      await client.query(
        "INSERT INTO images (url, filename, created_at) VALUES ($1, $2, NOW())",
        [uploadResult.secure_url, filename]
      );
    } finally {
      client.release();
    }
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        url: uploadResult.secure_url
      })
    };
  } catch (error) {
    console.error("Upload error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
}
async function parseMultipart(event) {
  const contentType = event.headers["content-type"] || "";
  if (!contentType.includes("multipart/form-data")) {
    throw new Error("Invalid content type");
  }
  const boundary = contentType.split("boundary=")[1];
  const body = Buffer.from(event.body, event.isBase64Encoded ? "base64" : "utf8");
  let file = null;
  let filename = "image.jpg";
  const parts = body.toString("utf8").split(`--${boundary}`);
  for (const part of parts) {
    if (part.includes("filename=")) {
      const filenameMatch = part.match(/filename="([^"]+)"/);
      if (filenameMatch) {
        filename = filenameMatch[1];
      }
      const fileStart = part.indexOf("\r\n\r\n") + 4;
      const fileEnd = part.lastIndexOf("\r\n");
      file = body.slice(
        body.indexOf(part) + fileStart,
        body.indexOf(part) + fileEnd
      );
      break;
    }
  }
  return { file, filename };
}
function uploadToCloudinary(buffer, filename) {
  return new Promise((resolve, reject) => {
    const stream = import_cloudinary.v2.uploader.upload_stream(
      {
        resource_type: "auto",
        public_id: `portfolio/${Date.now()}`
      },
      (error, result) => {
        if (error) reject(error);
        else resolve(result);
      }
    );
    stream.end(buffer);
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
