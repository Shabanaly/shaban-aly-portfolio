var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var upload_image_exports = {};
__export(upload_image_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(upload_image_exports);
var import_cloudinary = require("cloudinary");
var import_pg = require("pg");
import_cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});
const pool = new import_pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});
function parseMultipartForm(event) {
  const contentType = event.headers["content-type"] || event.headers["Content-Type"];
  if (!contentType || !contentType.includes("multipart/form-data")) {
    throw new Error("Invalid multipart form-data");
  }
  const boundaryKey = "boundary=";
  const boundary = "--" + contentType.substring(
    contentType.indexOf(boundaryKey) + boundaryKey.length
  );
  const bodyBuffer = Buffer.from(
    event.body,
    event.isBase64Encoded ? "base64" : "utf8"
  );
  const parts = [];
  let start = bodyBuffer.indexOf(boundary);
  while (start !== -1) {
    const end = bodyBuffer.indexOf(boundary, start + boundary.length);
    if (end === -1) break;
    const part = bodyBuffer.slice(start + boundary.length, end);
    parts.push(part);
    start = end;
  }
  for (const part of parts) {
    const headerEnd = part.indexOf("\r\n\r\n");
    if (headerEnd === -1) continue;
    const header = part.slice(0, headerEnd).toString();
    const content = part.slice(headerEnd + 4).slice(0, -2);
    if (header.includes("filename=")) {
      const match = header.match(/filename="([^"]+)"/);
      const filename = match ? match[1] : `image-${Date.now()}`;
      return { fileBuffer: content, filename };
    }
  }
  return { fileBuffer: null, filename: null };
}
function uploadToCloudinary(buffer, filename) {
  return new Promise((resolve, reject) => {
    const upload = import_cloudinary.v2.uploader.upload_stream(
      {
        resource_type: "image",
        type: "upload",
        folder: "projects",
        public_id: `${Date.now()}`
      },
      (err, result) => {
        if (err) reject(err);
        else resolve(result);
      }
    );
    upload.end(buffer);
  });
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { fileBuffer, filename } = parseMultipartForm(event);
    if (!fileBuffer) {
      throw new Error("No image file detected");
    }
    const uploadResult = await uploadToCloudinary(fileBuffer, filename);
    const client = await pool.connect();
    await client.query(
      "INSERT INTO images (url, filename, created_at) VALUES ($1, $2, NOW())",
      [uploadResult.secure_url, filename]
    );
    client.release();
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: true,
        url: uploadResult.secure_url
      })
    };
  } catch (error) {
    console.error("Upload error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
